const defaults=[
{id:1,name:"Android Non Root Panel",category:"Non Root",price:99,validity:"30 Days",mode:"Manual Mode",desc:"Digital panel product. Delivery is completed after successful payment."},
{id:2,name:"Android Root Panel",category:"Root",price:149,validity:"30 Days",mode:"API Mode",desc:"API delivery-ready product."},
{id:3,name:"iPhone Panel",category:"iPhone",price:199,validity:"30 Days",mode:"Manual Mode",desc:"iPhone product with editable validity."},
{id:4,name:"PC Panel",category:"PC",price:249,validity:"30 Days",mode:"API Mode",desc:"PC product with API delivery-ready mode."}];
let products=JSON.parse(localStorage.getItem("vicky_products")||"null")||defaults;
let active="All";
function render(){const cats=["All",...new Set(products.map(x=>x.category))];chips.innerHTML=cats.map(c=>`<button class="chip ${c===active?"active":""}" onclick="active='${c}';render()">${c}</button>`).join("");
const q=search.value.toLowerCase();let list=products.filter(x=>(active==="All"||x.category===active)&&(`${x.name} ${x.category}`.toLowerCase().includes(q)));
productGrid.innerHTML=list.length?list.map(x=>`<article class="card"><div class="thumb">V</div><div class="meta">${x.category} · ${x.mode}</div><h3>${x.name}</h3><div class="meta">Validity: ${x.validity}</div><div class="price">₹${Number(x.price).toFixed(2)}</div><button class="primary" onclick="openProduct(${x.id})">View & Buy</button></article>`).join(""):`<div class="panel">No products found.</div>`}
function openProduct(id){const x=products.find(p=>p.id===id);modalBody.innerHTML=`<div class="thumb">V</div><h2>${x.name}</h2><p class="meta">${x.category} · ${x.mode} · ${x.validity}</p><p>${x.desc}</p><h2>₹${Number(x.price).toFixed(2)}</h2><a class="primary" href="https://t.me/Vickystor_bot" target="_blank">Continue in Telegram</a><p class="meta">Payment gateway can be connected to this checkout through a secure backend.</p>`;modal.classList.add("show")}
function closeModal(){modal.classList.remove("show")} search.oninput=render;render();