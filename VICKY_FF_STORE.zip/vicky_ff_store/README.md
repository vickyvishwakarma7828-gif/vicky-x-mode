# VICKY FF STORE
Clean mobile-first product store starter.

## Run
Upload the folder to GitHub Pages or any static hosting. Open `index.html`.

## Admin
Open `/admin/` to manage the demo catalog. The current demo stores settings in browser localStorage.

## Important
The Fampay/automatic-payment section is UI-ready only. For real automatic payment verification, connect an official merchant/API integration through a secure server/backend. Do not expose secret credentials in frontend files.

Telegram:
- Bot: https://t.me/Vickystor_bot
- Channel: https://t.me/VickyXmodeofc
